<?php
	$db_username='username';
	$db_password='password';
?>

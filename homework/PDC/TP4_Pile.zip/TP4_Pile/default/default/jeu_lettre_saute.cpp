#include"dico.h"

#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#include<iostream>
using namespace std;

typedef int MatriceAdjacence_t[TAILLE_DICO][TAILLE_DICO];

bool Valid(const char *a, const char *b){
	if (strlen(a) != strlen(b))
		return false;
	if (!strcmp(a, b))
		return false;
	unsigned int i = 0, j = 0;
	while (i < strlen(a))
	{
		if (a[i] != b[i])
			if (j >= 1 || (i == strlen(a) - 1 && j < 1))
				return false;
			else
				j++;
		i++;
	}
	return true;
}

int Compare(const void *a, const void *b){
	return strcmp(*(char**)a, *(char**)b);
}

void CreeMatriceAdjacence(MatriceAdjacence_t mat){
	for (int i = 0; i < TAILLE_DICO; i++)
		for (int j = 0; j < TAILLE_DICO; j++)
			mat[i][j] = Valid(dico[i], dico[j]);
}

int ConvertionMotIndice(char *mot, char *dico_trie[TAILLE_DICO]){

}

typedef int i[100][100];
void test(i a){
	//a[10][0] = 100;
	*(*a + 10 * 100) = 1000;
	cout << a[10][0] << endl;
}


int main(int argc, char *argv[]){
	MatriceAdjacence_t *mat = (MatriceAdjacence_t *)malloc(sizeof(MatriceAdjacence_t));

	CreeMatriceAdjacence(*mat);

	//i *pi = (i*)malloc(sizeof(i));

	//*(**pi + 10 * 100) = 1000;

	//test(*pi);

	for (int i = 0; i < 100; i++)
		cout << *(**mat + i) << "    ";
	cout << endl;

	system("pause");
}

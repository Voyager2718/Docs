--------------------
 ``graphical_main``
--------------------

:doc:`back <index>`

.. automodule:: graphical_main
   :members:
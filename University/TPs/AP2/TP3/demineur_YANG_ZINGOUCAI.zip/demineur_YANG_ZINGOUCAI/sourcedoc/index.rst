------------------------
 demineur_YANG_ZINGOUCAI
------------------------

TOUTES LES FONCTIONS ONT ETE REALISE, graphical_main et console_main fonctionne aussi.

Question1: Le jeu est représenté sous forme d'un tableau à deux dimensions dont
quelques cases contiennent des mines cachées alors que d'autres sont vides.

Question2:     -constructeurs: permet de créer une donnée
               -sélecteurs: permet d'aller en récupérer une donnée
               -modificateurs: modifie l'une des données qui a été crée

               -Le sélecteur manquant est get_bombs(game)

.. toctree::
   :maxdepth: 1
			
   minesweeper
   graphicalboard
   graphical_main
   console_main

   
   



-------------------
 ``graphicalboard``
-------------------


:doc:`back <index>`

.. automodule:: graphicalboard
   :members:

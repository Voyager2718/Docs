------------------
 ``console_main``
------------------

:doc:`back <index>`

.. automodule:: console_main
   :members:
#!/usr/bin/python3
# -*- coding: utf-8 -*-

"""
:mod:`graphical_main`

:author: `Zhipeng YANG - Emilie ZINGOUCAI`

:date: 11 octobre 2015

This module uses from :mod:`minesweeper` and `graphical_main`


Runs the minesweeper game through the graphicalboard, in a console with the primary parameter width (default =30), the second height (default =20) and to finish number of bombs (default = 99).
When the graphical interface is displayed, click on a box to start the game. 
"""
import sys
import minesweeper as mines
import graphicalboard as graph

if __name__ == "__main__":
	assert len(sys.argv)==4, "Give me more arguments, please."
	assert int(sys.argv[1])>0 and int(sys.argv[2])>0 and int(sys.argv[3])>0, "All these arguments should be positive."
	graph.create(mines.make_game(int(sys.argv[1]), int(sys.argv[2]), int(sys.argv[3]))))
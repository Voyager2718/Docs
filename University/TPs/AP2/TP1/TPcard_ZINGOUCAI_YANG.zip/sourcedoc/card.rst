-----------------
 ``card`` module
-----------------


:doc:`back <index>`

Cards are defined by a value and a color. Possible values and colors are listed in card.values and card.colors. 
     
.. automodule:: card
   :members:

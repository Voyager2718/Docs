----------------------
 ``bataille`` module
----------------------

:doc:`back <index>`


.. automodule:: bataille
   :members:

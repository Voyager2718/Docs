//Version 0.14
//Class version 0.10
public class Entrance extends Room {
	public Entrance() {
		super("Entrance", "This is the entrance of the game.");
	}

	public String getDescription() {
		return this.description;
	}
}
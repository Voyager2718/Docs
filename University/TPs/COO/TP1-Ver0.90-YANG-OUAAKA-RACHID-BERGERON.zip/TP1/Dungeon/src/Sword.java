//Version 0.14
//Class version 0.10
public class Sword implements Equipment {

}

//Version 0.14
//Class version 0.10
public class Exit extends R {
	public Exit() {
		super("Exit", "This is the exit, you won.");
	}

	public String getDescription() {
		return this.description;
	}
}
//Version 0.14
//Class version 0.14
public class Treasure implements Equipment {
	private String name;
	private int value;

	public Treasure(String name, int value) {
		this.name = name;
		this.value = value;
	}

	public String getName() {
		return name;
	}

	public int getValue() {
		return value;
	}
}

/** 
* subclass of R
*/


public class Trap extends R {
	public Trap() {
		super("Trap", "This is a trap room, you lost.");
	}

	public String getDescription() {
		return this.description;
	}
}

/**
* class implements Equipment 
*/

public class Potion implements Equipment {

}

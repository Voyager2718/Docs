/**
* Key : class implements Equipment 
*/
public class Key implements Equipment {
	
}

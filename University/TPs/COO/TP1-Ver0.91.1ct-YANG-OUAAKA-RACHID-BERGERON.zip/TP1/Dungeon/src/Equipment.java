/** 
* interface Equipment 
*/
public interface Equipment {

}

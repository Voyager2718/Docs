/**
* class implements Equipment
 */

public class Sword implements Equipment {

}

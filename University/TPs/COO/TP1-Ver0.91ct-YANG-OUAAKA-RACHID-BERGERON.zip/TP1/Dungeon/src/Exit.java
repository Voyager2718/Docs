/**
* Exit : subclass of R it represents the exit
*/
public class Exit extends R {
	public Exit() {
		super("Exit", "This is the exit, you won.");
	}

	public String getDescription() {
		return this.description;
	}
}

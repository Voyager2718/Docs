/** 
 * the main class contains the main function
*/
public class main {
	public static void main(String args[]) {
		
	}
}

//Version 0.14
//Class version 0.25
public interface Equipment {

}

public class main {
	public static void main(String args[]) {
		Dungeon play = new Dungeon();
		play.start();
	}
}

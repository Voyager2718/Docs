/** 
* class Treasure implements Equipments she has two attributes, the constructor , the getters 
*/
public class Treasure implements Equipment {
	private String name;
	private int value;

	public Treasure(String name, int value) {
		this.name = name;
		this.value = value;
	}

	public String getName() {
		return name;
	}

	public int getValue() {
		return value;
	}
}

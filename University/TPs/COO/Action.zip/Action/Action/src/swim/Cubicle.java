package swim;

import resources.Resource;

public class Cubicle implements Resource {

	@Override
	public String description() {
		return null;
	}

	
}

package resources;

public class ResourcefulUser<R extends Resource> {
	protected R resource;

	public R getResource() {
		return resource;
	}

	public void setResource(R resource) {
		this.resource = resource;
	}

	public void reseResource() {
		this.resource = null;
	}
}

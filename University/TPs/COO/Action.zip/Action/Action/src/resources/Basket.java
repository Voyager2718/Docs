package resources;

public class Basket implements Resource {
	
	@Override
	public String description() {
		return "This is a basket.";
	}

}

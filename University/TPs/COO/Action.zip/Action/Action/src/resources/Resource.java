package resources;

public interface Resource {
	public String description();
}
